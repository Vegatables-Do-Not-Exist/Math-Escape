const arrowLeft = document.getElementById('arrow-left');
const coffeePot = document.getElementById('coffee-pot');

arrowLeft.addEventListener('click', () => {
  window.location.href = 'doors.html';
});

coffeePot.addEventListener('click', () => {
  alert('You picked up the coffee pot!');
  localStorage.setItem('hasCoffee', 'true');
  coffeePot.style.display = 'none';
});
