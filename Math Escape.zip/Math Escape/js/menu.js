function selectGrade(grade) {
  localStorage.setItem("selectedGrade", grade);
  window.location.href = "game.html"; // sends to main game
}
