// Load grade for math problems
const grade = localStorage.getItem('selectedGrade') || '6';

// Locker data - codes and hints based on grade
const lockersData = [
  { id: 1, hint: '', code: '', content: 'empty' },
  { id: 2, hint: '', code: '', content: 'exitNote1' },
  { id: 3, hint: '', code: '', content: 'empty' },
  { id: 4, hint: '', code: '', content: 'key' },
  { id: 5, hint: '', code: '', content: 'exitNote3' },
];

// Define math problems per locker per grade
const lockerMathProblems = {
  '6': [
    { hint: 'What is 10 + 5?', code: '15' },
    { hint: 'What is 9 × 2?', code: '18' },
    { hint: 'What is 7 + 4?', code: '11' },
    { hint: 'What is 8 × 3?', code: '24' },
    { hint: 'What is 14 - 7?', code: '7' },
  ],
  '7H': [
    { hint: 'What is 15 + 9?', code: '24' },
    { hint: 'What is 12 × 2?', code: '24' },
    { hint: 'What is 17 + 8?', code: '25' },
    { hint: 'What is 18 ÷ 3?', code: '6' },
    { hint: 'What is 21 - 13?', code: '8' },
  ],
};

// Elements
const lockersContainer = document.getElementById('lockers-container');
const lockerPopup = document.getElementById('locker-popup');
const lockerHint = document.getElementById('locker-hint');
const lockerCodeInput = document.getElementById('locker-code-input');
const lockerCodeSubmit = document.getElementById('locker-code-submit');
const lockerMessage = document.getElementById('locker-message');
const lockerClose = document.getElementById('locker-close');

let currentLocker = null;
let lockerUnlocked = Array(lockersData.length).fill(false);

// Initialize lockers
function createLockers() {
  const problems = lockerMathProblems[grade];
  lockersData.forEach((locker, index) => {
    locker.hint = problems[index].hint;
    locker.code = problems[index].code;

    const lockerDiv = document.createElement('div');
    lockerDiv.classList.add('locker');
    lockerDiv.id = `locker-${locker.id}`;
    lockerDiv.title = `Locker ${locker.id}`;
    lockerDiv.addEventListener('click', () => openLocker(locker.id - 1));
    lockersContainer.appendChild(lockerDiv);
  });
}

// Open locker popup
function openLocker(index) {
  if (lockerUnlocked[index]) return; // Already unlocked

  currentLocker = index;
  lockerHint.textContent = lockersData[index].hint;
  lockerCodeInput.value = '';
  lockerMessage.textContent = '';
  lockerPopup.classList.remove('hidden');
  lockerCodeInput.focus();
}

// Close locker popup
lockerClose.addEventListener('click', () => {
  lockerPopup.classList.add('hidden');
  currentLocker = null;
});

// Submit locker code
lockerCodeSubmit.addEventListener('click', () => {
  const inputCode = lockerCodeInput.value.trim();
  if (!currentLocker && currentLocker !== 0) return;

  const correctCode = lockersData[currentLocker].code;
  if (inputCode === correctCode) {
    lockerMessage.style.color = 'lime';
    lockerMessage.textContent = 'Unlocked!';

    lockerUnlocked[currentLocker] = true;
    lockerPopup.classList.add('hidden');
    updateLockerVisual(currentLocker);

    // Give player item or note if locker contains it
    const content = lockersData[currentLocker].content;
    if (content === 'key') {
      alert('You found a key inside this locker! It might open Mr. Clock’s door.');
      // TODO: Save key to player inventory
      localStorage.setItem('hasClockKey', 'true');
    } else if (content.startsWith('exitNote')) {
      alert(`You found Exit Code Note ${content.slice(-1)}!`);
      // TODO: Save exit note
      let notes = JSON.parse(localStorage.getItem('exitNotes') || '[]');
      if (!notes.includes(content)) {
        notes.push(content);
        localStorage.setItem('exitNotes', JSON.stringify(notes));
      }
    } else {
      alert('Locker is empty.');
    }

  } else {
    lockerMessage.style.color = 'red';
    lockerMessage.textContent = 'Incorrect code. Try again.';
  }
});

// Update locker image when unlocked
function updateLockerVisual(index) {
  const lockerDiv = document.getElementById(`locker-${lockersData[index].id}`);
  lockerDiv.classList.add('open');
  lockerDiv.style.cursor = 'default';
  lockerDiv.removeEventListener('click', () => openLocker(index));
}

// Navigation arrows

document.getElementById('arrow-left').addEventListener('click', () => {
  // Back to classroom
  window.location.href = 'game.html';
});

document.getElementById('arrow-right').addEventListener('click', () => {
  // Move to next hallway segment (doors)
  window.location.href = 'doors.html';
});

// Initialize on page load
createLockers();
