const dialogueText = document.getElementById('dialogue-text');
const dialogueNext = document.getElementById('dialogue-next');
const arrowLeft = document.getElementById('arrow-left');

const dialogues = [
  "Hello there, student! I've been expecting you.",
  "I see you have the key to my door. Good.",
  "I have a key that might help you access the Teacher's Lounge.",
  "But first, can you tell me the answer to this: What is 8 × 7?",
  // This question should be answered by player - simplified for now
  // We'll simulate the player giving correct answer on button press for now
  "Correct! Here's the key to the Teacher's Lounge. Use it wisely.",
  "Good luck!"
];

let step = 0;

// Start dialogue
dialogueText.textContent = dialogues[step];

dialogueNext.addEventListener('click', () => {
  step++;

  if (step === 3) {
    // Prompt for answer to 8 x 7 question
    const answer = prompt("What is 8 × 7?");
    if (answer.trim() === '56') {
      step++; // next dialogue with key given
      localStorage.setItem('hasLoungeKey', 'true');
      alert("You received the Teacher's Lounge key!");
    } else {
      alert("That's not correct. Try talking to me again.");
      step = 2; // repeat question
    }
  }

  if (step >= dialogues.length) {
    // End dialogue, return to doors
    window.location.href = 'doors.html';
  } else {
    dialogueText.textContent = dialogues[step];
  }
});

arrowLeft.addEventListener('click', () => {
  window.location.href = 'doors.html';
});
