// Load selected grade from localStorage
const grade = localStorage.getItem('selectedGrade') || '6';

// Simple math problems for each grade
const mathProblems = {
  '6': {
    question: '12 + 7',
    answer: '19',
  },
  '7H': {
    question: '5 × 9',
    answer: '45',
  }
};

const mathProblemPanel = document.getElementById('math-problem-panel');
const mathProblemText = document.getElementById('math-problem');
const closetInput = document.getElementById('closet-code-input');
const closetSubmit = document.getElementById('closet-code-submit');
const closetMessage = document.getElementById('closet-message');
const stickyNote = document.getElementById('sticky-note');
const closetDoor = document.getElementById('closet-door');
const teacher = document.getElementById('teacher');

// Show the problem text
mathProblemText.textContent = mathProblems[grade].question;

// Sticky note found flag
let stickyFound = false;

// Click teacher to reveal sticky note
teacher.addEventListener('click', () => {
  if (!stickyFound) {
    stickyNote.style.display = 'block';
    stickyFound = true;
    alert('You found a sticky note: "CLST code don\'t forget!"');
  }
});

// Click sticky note to read it (optional, you can extend)
stickyNote.addEventListener('click', () => {
  alert('The sticky note says: "CLST code don\'t forget!"');
});

// Closet door click and code entry
closetSubmit.addEventListener('click', () => {
  const code = closetInput.value.trim();
  if (code === mathProblems[grade].answer) {
    closetMessage.style.color = 'lime';
    closetMessage.textContent = 'Closet unlocked! You found a key inside.';
    // TODO: Add logic to pick up key and unlock door to hallway
  } else {
    closetMessage.style.color = 'red';
    closetMessage.textContent = 'Incorrect code. Try again.';
  }
});
