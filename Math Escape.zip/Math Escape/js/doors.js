// Navigation arrows
document.getElementById('arrow-left').addEventListener('click', () => {
  window.location.href = 'hallway.html';
});

const doorClock = document.getElementById('door-clock');
const doorLounge = document.getElementById('door-lounge');

// Check if player has Mr. Clock key
const hasClockKey = localStorage.getItem('hasClockKey') === 'true';

// Flag for if player has teacher's lounge key
let hasLoungeKey = localStorage.getItem('hasLoungeKey') === 'true';

// Interaction with Mr. Clock's door
doorClock.addEventListener('click', () => {
  if (!hasClockKey) {
    alert("The door is locked. You need Mr. Clock's key.");
    return;
  }
  // Save current location and go to Mr. Clock room
  window.location.href = 'mrclock.html';
});

// Interaction with Teacher's Lounge door
doorLounge.addEventListener('click', () => {
  if (!hasLoungeKey) {
    alert("The door is locked. You need a key.");
    return;
  }
  window.location.href = 'teacherslounge.html';
});
